<?php 

	// app vars
	$app_name = 'Segurança 4.0'; // [ X ] - Trocar o nome do app

?>